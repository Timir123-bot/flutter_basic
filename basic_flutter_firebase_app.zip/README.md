# Basic Flutter Application with Firebase

Beginner-level Flutter app implementing Firebase Authentication.
